<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'jobdesk';

$conn = mysqli_connect($hostname, $username, $password, $database);
